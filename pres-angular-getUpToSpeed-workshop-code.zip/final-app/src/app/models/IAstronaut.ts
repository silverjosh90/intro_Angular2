export interface IAstronaut {
  id: string;
  first_name: string;
  last_name: string;
  wiki_href: string;
  image: string;
}
