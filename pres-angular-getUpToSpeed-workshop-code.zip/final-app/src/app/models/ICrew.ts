export interface ICrew {
  role?: string;
  astronaut_id?: string;
}
