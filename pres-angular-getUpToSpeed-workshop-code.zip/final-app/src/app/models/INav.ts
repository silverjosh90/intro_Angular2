export interface INav {
  link: string;
  name: string;
  exact: boolean;
}
